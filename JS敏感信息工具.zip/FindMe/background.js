// @Date    : 2020-09-12 16:26:48
// @Author  : residuallaugh
var js = [];
var search_data = {};
var static_file = ['.jpg', '.png', '.gif', '.css', '.svg', '.ico', '.js'];
var key = ["sensitiveInfo", "ip", "ip_port", "domain", "path", "url", "sfz", "mobile", "mail", "jwt"];
function get_js() {
  return js;
}
function add_js(js_name) {
  js.push(js_name);
}
function unique(arr) {
  if (arr == 'null') {
    return null;
  }
  var array = [];
  for (var i = 0; i < arr.length; i++) {
    if (array.indexOf(arr[i]) === -1) {
      array.push(arr[i])
    }
  }
  return array
}
//查找search_data中是否已经存在了，如果已存在则不返回
function find(arr1, arr2) {
  var arr3 = []
  arr1.forEach(function (item, index, array) {
    if (arr2.indexOf(item) == -1) {
      arr3.push(item)
    }
  })
  return arr3
}
//去重合并两个数组 并集
function add(arr1, arr2) {
  arr1.forEach(function (item, index, array) {
    if (arr2.indexOf(item) == -1) {
      arr2.push(item)
    }
  })
  return arr2
}

//交集
function jiaoji(arr1, arr2) {
  var arr3 = [];
  arr1.forEach(function (item, index, array) {
    if (arr2.indexOf(item) > -1) {
      arr3.push(item)
    }
  })
  return arr3
}


function collect_static(arr1, arr2) {
  var arr3 = arr1.slice(0, arr1.length);
  arr1.forEach(function (item, index, array) {
    for (var i = 0; i < static_file.length; i++) {
      if (item.indexOf(static_file[i]) != -1) {
        arr2.push(item)
        arr3.splice(arr3.indexOf(item), 1)
      }
    }
  })
  return { 'arr1': arr3, 'static': arr2 }
}

function sub_1(arr1) {
  var arr3 = []
  arr1.forEach(function (item, index, array) {
    arr3.push(item.substring(1, item.length - 1))
  })
  return arr3
}

chrome.runtime.onMessage.addListener(
  function (request, sender, sendResponse) {
    if (request.greeting == "result") {
      var tmp_data = request.data;

      //输出发现有null也有值传进来
      //alert("1："+request.data["sensitiveInfo"]);

      //遍历所有数据类型
      for (var i = 0; i < key.length; i++) {
        //如果传入的数据没有这个类型，就看下一个
        if (tmp_data[key[i]] == null) {
          continue;
        }

        //敏感信息可以到达这里
        //alert("2："+tmp_data[key[i]]);

        // 把前端的处理放到这里避免重复
        if (key[i] != "sensitiveInfo") {
          tmp_data[key[i]] = sub_1(tmp_data[key[i]])
        }

        //这里数据被过滤了，对上一步进行跳过。跳过对敏感信息的过滤以后，可以正常通过这里
        // alert("3："+tmp_data[key[i]]);
        //如果search_data有历史数据，进行检查
        if (tmp_data['current'] in search_data) {
          for (var j = 0; j < key.length; j++) {
            if (key[i] != "sensitiveInfo") {
              if (search_data[tmp_data['current']][key[j]] != null) {
                tmp_data[key[i]] = jiaoji(unique(tmp_data[key[i]]), find(unique(tmp_data[key[i]]), search_data[tmp_data['current']][key[j]]))
              }
            }
          }
          //这里Sensitiveinfo被过滤了,回头给if特权跳过
          // if(key[i]="sensitiveInfo"){
          //   alert("4："+tmp_data[key[i]]);
          // }
        } else {
          search_data[tmp_data['current']] = {}
        }
        if (tmp_data['current'] in search_data && search_data[tmp_data['current']][key[i]] != null) {
          var search_data_value = unique(add(search_data[tmp_data['current']][key[i]], tmp_data[key[i]])).sort()
          if ('static' in search_data[tmp_data['current']]) {
            var res = collect_static(search_data_value, search_data[tmp_data['current']]['static'])
          } else {
            var res = collect_static(search_data_value, [])
          }
          search_data[tmp_data['current']][key[i]] = res['arr1']
          search_data[tmp_data['current']]['static'] = res['static']
        } else {
          var search_data_value = unique(tmp_data[key[i]]).sort()
          // alert(search_data_value);
          if ('static' in search_data[tmp_data['current']]) {
            var res = collect_static(search_data_value, search_data[tmp_data['current']]['static'])
          } else {
            var res = collect_static(search_data_value, [])
          }
          search_data[tmp_data['current']]['static'] = res['static']
          search_data[tmp_data['current']][key[i]] = res['arr1']
        }
      }

    }
  });


function result(host) {
  return search_data[host];
}
