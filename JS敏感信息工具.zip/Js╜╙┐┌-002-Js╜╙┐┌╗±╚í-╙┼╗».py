from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import re
import random
import requests

#  这是标题~
def title():
    print('+------------------------------------------')
    print('+  \033[34m.......初始化开始.......                               \033[0m')
    print('+  \033[34mTop:    杳   若    出品                               \033[0m')
    print('+  \033[34mTitle: 用于Url爬取Js接口                          \033[0m')
    print('+  \033[36m使用格式:  输入必要的参数                                          \033[0m')
    print('+------------------------------------------')

# 请求头伪造
def usera():
        user_agent_list = [
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/45.0.2454.85 Safari/537.36 115Browser/6.0.3',
            'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_8; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
            'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-us) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
            'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.0; Trident/4.0)',
            'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.0)',
            'Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1',
            'Opera/9.80 (Windows NT 6.1; U; en) Presto/2.8.131 Version/11.11',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_0) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.56 Safari/535.11',
            'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; Trident/4.0; SE 2.X MetaSr 1.0; SE 2.X MetaSr 1.0; .NET CLR 2.0.50727; SE 2.X MetaSr 1.0)',
            'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; Trident/5.0',
            'Mozilla/5.0 (Windows NT 6.1; rv:2.0.1) Gecko/20100101 Firefox/4.0.1',
            'Mozilla/5.0 (Windows x86; rv:19.0) Gecko/20100101 Firefox/19.0',
            'Mozilla/5.0 (Windows NT 4.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2049.0 Safari/537.36',
            'Mozilla/5.0 (Microsoft Windows NT 6.2.9200.0); rv:22.0) Gecko/20130405 Firefox/22.0',
            'Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/30.0.1599.17 Safari/537.36',
            'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1468.0 Safari/537.36',
        ]
        # 随机选择一个
        user_agent = random.choice(user_agent_list)
        # 传递给header
        headers = {'User-Agent': user_agent, }
        return headers

#  模块一、获取url打印的源码
def get_xpath(url):
    gg.get(url)
    get_url = gg.page_source
    gg.close()
    return get_url

#  模块二、过滤获得的url源码，取得其中的js接口内容
def get_js(get_url):
    list_js = re.findall('".*?.js.*?"',get_url)
    return list_js

#  模块三、数组可能有误报，简单过滤一次
def del_js(js_li):
    true_js = []
    for js in js_li:
        if '.js' in js:
            true_js.append(js)
    return true_js

#  模块四、存在标签获取标签内的内容，过滤掉无用信息
def lo_js(true_js):
    true1_js = []
    for js in true_js:
        if 'src="' in js:
            js = re.findall('src="(.*?)"',js)[0]
            true1_js.append(js)
        elif '"' in js :
            js = re.findall('"(.*?)"', js)[0]
            true1_js.append(js)
        else:
            true1_js.append(js)
    return true1_js

#  模块五、判定是https还是http类型，然后拼接url，获取所有js的地址
def js_url(urls,true1_js):
    true2_js = []
    for js in true1_js:
        if 'https://'in js:
            true2_js.append(js)
        elif 'http://' in js:
            true2_js.append(js)
        else:
            js = urls + js
            true2_js.append(js)
    num1 = len(true2_js)
    print("\033[36m[o] 初步js地址获取完成，共有\033[0m", end='')
    print("\033[35m {} \033[0m".format(str(num1)), end='')
    print("\033[36m条js接口地址\033[0m")
    return true2_js

#  模块六、去重
def out_js(true2_js):
    qu_js = []
    c = []
    for url in true2_js:
        if url in str(c):
            pass
        else:
            c.append(url)
            qu_js.append(url)
    num1 = len(qu_js)
    print("\033[36m[o] 列表去重完成，去重完成之后还有\033[0m", end='')
    print("\033[35m {} \033[0m".format(str(num1)), end='')
    print("\033[36m条js接口地址\033[0m")
    return qu_js

#  模块七、是否需要搜索js中的内容，是否存在敏感信息
def souch_js(qu_js):
    #  显示设置
    #  如果watch为0 默认不显示获得的接口地址
    watch = input('是否需要展示js地址，需要输入1，不然输入0：')
    if watch == '1' :
        for a in watch_js:
            print(a)
    souch_js = input('是否需要爬取js内是否存在敏感内容，需要输入1，不然输入0：')
    if souch_js == '1' :
        for url in qu_js:
            book = requests.get(url=url,headers=usera(),timeout=5)
            key = ''
            sound_user = re.compile(r'username', re.I)
            result4 = sound_user.search(book.text)
            if result4:
                key = key + '|用户信息'
            sound_password = re.compile(r'password', re.I)
            result = sound_password.search(book.text)
            if result:
                key = key + '|password'
            sound_pwd = re.compile(r'pwd', re.I)
            result1 = sound_pwd.search(book.text)
            if result1:
                key = key + '|pwd'
            if '密码' in book.text:
                key = key + '|密码'
            sound_app = re.compile(r'app', re.I)
            result2 = sound_app.search(book.text)
            if result2:
                key = key + '|app'
            sound_api = re.compile(r'api', re.I)
            result3 = sound_api.search(book.text)
            if result3:
                key = key + '|api'
            if key != '':
                print("\033[36m [o]{} \033[0m".format(url), end='')
                print("\033[35m 疑似存在敏感信息为\033[0m", end='')
                print("\033[36m {}| \033[0m".format(key))
            else:
                print("\033[33m [x]{} \033[0m".format(url), end='')
                print("\033[34m 不存在敏感信息\033[0m")

if __name__ == '__main__':
    title()
    url = input("请输入需要捕获的url,注意需要开头：")

    #  初始化配置、无头浏览器
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')  # 无头化设置
    chrome_options.add_argument(
        'user-agent="Mozilla/5.0 (iPod; U; CPU iPhone OS 2_1 like Mac OS X; ja-jp) AppleWebKit/525.18.1 (KHTML, like Gecko) Version/3.1.1 Mobile/5F137 Safari/525.20"')
    gg = webdriver.Chrome(options=chrome_options)
    gg.set_page_load_timeout(30)

    #  初始化设置、判定https还是http，需要拼接的内容
    if 'https://' in url:
        url1 = url.replace('https://','')
        urls, p2, p3 = url1.partition('/')
        urls = 'https://' + urls
    else:
        url1 = url.replace('http://','')
        urls, p2, p3 = url1.partition('/')
        urls = 'http://' + urls
    urls = urls + '/'

    #  设置
    js_li = get_js(get_xpath(url))
    true1_js = lo_js(del_js(js_li))
    watch_js = out_js(js_url(urls, true1_js))
    souch_js(watch_js)


